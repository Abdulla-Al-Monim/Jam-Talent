<?php 
return[
	"Messages"=>"Mesajlar",
	"Home"=>"Ev",
	"Dashboard"=>"Gösterge Paneli",
	"First you send message anyone"=>"İlk önce birine mesaj atarsın",
	"Send"=>"Göndermek",


"Messages"=>"Mesajlar",						
"Home"=>"Ev",						
"Dashboard"=>"Gösterge Paneli",						
"First you send message anyone"=>"İlk önce birine mesaj atarsın",						
"Send"=>"Göndermek",						
"Your Message"=>"Mesajın",
];