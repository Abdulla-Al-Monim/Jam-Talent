<?php 
return[
	"Home"=>"Ev",
	"Knowledge Hub"=>"Bilgi Merkezi",
	"There is no blog posted in this category"=>"Bu kategoride yayınlanmış bir blog yok",
	"Trending Posts"=>"Trend Olan Gönderiler",
	"Social Profiles"=>"Sosyal Profiller",
	"Interesting"=>"İlginç",
	"Share It!"=>"Paylaş!",
	"Blog Post"=>"Blog yazısı",
	"Blog Post page"=>"Blog Gönderisi sayfası",
	"Blog"=>"Blog",
	"Recent Posts"=>"yakın zamanda Gönderilenler",
	"Featured Posts"=>"Öne çıkan gönderiler",
	"Tags"=>"Etiketler",


	"Home"=>"Ev",							
	"Knowledge Hub"=>"Bilgi Merkezi",							
	"There is no blog posted in this category"=>"Bu kategoride yayınlanmış bir blog yok",							
	"Trending Posts"=>"Trend Olan Gönderiler",							
	"Social Profiles"=>"Sosyal Profiller",							
	"Interesting"=>"İlginç",							
	"Share It!"=>"Paylaş!",							
	"Blog Post"=>"Blog yazısı",							
	"Blog Post page"=>"Blog Gönderisi sayfası",							
	"Blog"=>"Blog",							
	"Recent Posts"=>"yakın zamanda Gönderilenler",							
	"Featured Posts"=>"Öne çıkan gönderiler",							
	"Tags"=>"Etiketler",
	"Showcase your knowledge & skills to get hired faster"=>"Daha hızlı işe alınmak için bilgi ve becerilerinizi sergileyin",							

];