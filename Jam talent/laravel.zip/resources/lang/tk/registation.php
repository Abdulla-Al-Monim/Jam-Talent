<?php 
return [
	"One Account - All of Jam"=>  "Bir Hesap - Tüm Jam",
    "Powered by Jam Unity"=> "Jam Unity tarafından desteklenmektedir.",
    "Dont have Account Sign Up!"=> "Hesabınız yok mu?, Kayıt ol!",
    "Log In"=> "Giriş Yap",
    "Forgot Password?"=>  "Parolanızı mı unuttunuz?",
    
    "Freelancer" => "Serbest çalışan",
    "Employer" =>"İş veren",
    "Email Address"=> "E-mail Adres",
    
    "Password"=> "Parola",
    "Repeat Password"=> "Şifreyi tekrar girin",
    "Already have an account?" => "Zaten hesabınız var mı?",
    "REGISTER"=>"KAYIT OL",

    "One Account - All of Jam"=>  "Bir Hesap - Tüm Jam",					
    "Powered by Jam Unity"=> "Jam Unity tarafından desteklenmektedir.",						
    "Dont have Account Sign Up!"=> "Hesabınız yok mu?, Kayıt ol!",						
    "Log In"=> "Giriş Yap",						
    "Forgot Password?"=>  "Parolanızı mı unuttunuz?",
    "Freelancer" => "Serbest çalışan",						
    "Employer" =>"İş veren",						
    "Email Address"=> "E-mail Adres",
    "Password"=> "Parola",						
    "Repeat Password"=> "Şifreyi tekrar girin",						
    "Already have an account?" => "Zaten hesabınız var mı?",						
    "REGISTER"=>"KAYIT OL",						

];