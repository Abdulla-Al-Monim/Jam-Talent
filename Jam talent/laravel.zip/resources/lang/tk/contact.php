<?php 
return[
	"get in touch"=>"temasta olmak",
	"Full Name"=>"Full Name",
	"Email"=>"Ad Soyad",
	"Phone Number"=>"Telefon numarası",
	"Messages"=>"Mesajlar",
	"SEND"=>"GÖNDERMEK",
	"Contact Information"=>"İletişim bilgileri",

	"get in touch"=>"İletişim Kur",
"Full Name"=>"Ad Soyad",
"Email"=>"E-posta",
"Phone Number"=>"Telefon Numarası",
"Messages"=>"Mesajlar",
"SEND"=>"GÖNDER",
"Contact Information"=>"İletişim bilgileri",

];