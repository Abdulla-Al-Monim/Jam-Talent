<?php 
return [
	"Order Id"=>"Sipariş Kimliği",
	"Employer name"=>"işveren adı",
	"Earning balance"=>"Kazanç Bakiyesi",
	"Order type"=>"Sipariş türü",
	"Completed date"=>"Tamamlanma tarihi",
	"Status"=>"Durum",
	"Custom Offer"=>"Özel Teklif",
	"Bid Order"=>"Teklif Sırası",
	"Payment within 14 days"=>"14 gün içinde ödeme",
	"Complete"=>"Tamamlayınız",
	"Total Earn"=>"Toplam Kazanç",
	"Earning"=>"kazanç",


	"Order Id"=>"İş Kimliği",
"Employer name"=>"İşveren Adı",
"Earning balance"=>"Kazanç Bakiyesi",
"Order type"=>"İş türü",
"Completed date"=>"Tamamlanma tarihi",
"Status"=>"Durum",
"Custom Offer"=>"Özel Teklif",
"Bid Order"=>"Teklif Sırası",
"Payment within 14 days"=>"14 gün içinde ödeme",
"Complete"=>"Tamamlayınız",
"Total Earn"=>"Toplam Kazanç",
"Earning"=>"Kazanç",

];