<?php 
return [
 	"Custom Offer Payment"=>"Özel Teklif Ödemesi",
 	"Employer Name"=>"İşveren Adı",
 	"Freelancer Name" =>"Serbest Çalışan Adı",
 	"Transaction id"  =>"İşlem Kimliği",
 	"Post date"=>"Yayınlanma tarihi",
 	"Custom Offer"  =>"Özel Teklif",
 	"Job Payment"=>"İş Ödemesi",
 	"Employer Name" =>"İşveren Adı",
 	"Freelancer Name"=>"Serbest Çalışan Adı",
 	"Budget"=>"Bütçe",
 	"Task Payment"=>"Görev Ödemesi",
    "Task Title"=>"Görev Başlığı",
    "Job Title"=>"İş ismi",



	"Custom Offer Payment"=>"Özel Teklif Ödemesi",				
	"Employer Name"=>"İşveren Adı",				
	"Freelancer Name" =>"Serbest Çalışan Adı",				
	"Transaction id"  =>"İşlem Kimliği",				
	"Post date"=>"Yayınlanma tarihi",				
	"Custom Offer"  =>"Özel Teklif",				
	"Job Payment"=>"İş Ödemesi",				
	"Employer Name" =>"İşveren Adı",				
	"Freelancer Name"=>"Serbest Çalışan Adı",				
	"Budget"=>"Bütçe",				
	"Task Payment"=>"Görev Ödemesi",				
	"Task Title"=>"Görev Başlığı",					
	"Job Title"=>"İş ismi",					

];
