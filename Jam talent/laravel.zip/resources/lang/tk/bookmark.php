<?php 
	return[
		"Bookmarks"=>"Yer imleri",
		"Bookmarked Freelancers"=>"Bookmarked Freelancers",
		"Unknown"=>"Bilinmeyen",
		"Home"=>"Ev",
		"Dashboard"=>"Gösterge Paneli",
		"Bookmarked Jobs"=>"İşaretli İşler",
		"Bookmarked Task"=>"İşaretli Görev",



		"Bookmarks"=>"Yer işaretleri",
		"Bookmarked Freelancers"=>"İşaretlenmiş Serbest Çalışanlar",
		"Unknown"=>"Bilinmeyen",
		"Home"=>"Ana sayfa",
		"Dashboard"=>"Gösterge Paneli",
		"Bookmarked Jobs"=>"İşaretli İşler",
		"Bookmarked Task"=>"İşaretli Görev",

	];