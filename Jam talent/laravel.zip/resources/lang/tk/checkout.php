<?php 
 return[
 	"All Membership Payments"=>"Tüm Üyelik Ödemeleri",
 	"Employer Name"=>"İşveren Adı",
 	"Plan name"=>"Planın adı",
 	"Transcection id"=>"İşlem Kimliği",
 	"Expired date"=>"Son kullanma tarihi geçmiş",


	 "All Membership Payments"=>"Tüm Üyelik Ödemeleri",
"Employer Name"=>"İşveren Adı",
"Plan name"=>"Planın adı",
"Transcection id"=>"İşlem Kimliği",
"Expired date"=>"Son kullanma tarihi geçmiş",

 ];