<?php
return [
    "Let’s get to 
work"=>"Hadi çalışalım",
	"Let’s get to 
work"=>"Hadi çalışalım",
"Build relationships and create your own Virtual Talent Bench™ for quick project turnarounds or big transformations." =>"Hızlı proje geri dönüşleri veya büyük dönüşümler için ilişkiler kurun ve kendi Virtual Talent Bench™'inizi yaratın.",

 "Connect with talent that gets you with Talent Marketplace
             Post your job on the world’s work marketplace and wait for the proposals to flood in from talented people around the world. Our advanced algorithms help you shortlist candidates who are the best fit. And you can check profiles, portfolios, and reviews before you give someone the green light." => "Talent Marketplace ile sizi yakalayan yeteneklerle bağlantı kurun. Dünyanın iş piyasasında işinizi yayınlayın ve dünyanın her yerinden yetenekli insanlardan teklif gelmesini bekleyin. Gelişmiş algoritmalarımız, en uygun adayları listeye almanıza yardımcı olur. Birisine yeşil ışık yakmadan önce profilleri, portföyleri ve incelemeleri kontrol edebilirsiniz.",

            "Post a job and hire a pro" =>"Bir iş ilanı verin veya bir profesyonel kiralayın",
            "All in one place" => "Hepsi bir yerde",
            "Once you sign in you’ll get 
your own online space to 
manage your project.
Use it to securely send and 
receive files, give real-time 
feedback and make 
payments. And if you’re 
out and about a lot, 
you’ll want to download
 the app too." => "Oturum açtığınızda, projenizi yönetmek için kendi çevrimiçi alanınıza sahip olacaksınız. Dosyaları güvenli bir şekilde göndermek ve almak, gerçek zamanlı geri bildirim vermek ve ödeme yapmak için bunu kullanın. Dışarıya çok çıkıyorsanız, uygulamayı da indirmek istersin.",
"Find Talent" => "Yetenek Bul",
"Filter bidding from top 
talents" => "En iyi yeteneklerden gelen teklifleri filtreleyin",
"Bid for task: In this system,
 the freelancers can bid for 
the task posted by the 
employer by giving the 
overall quotation." => "Görev için teklif verme: Bu sistemde freelance çalışanlar, işverenin verdiği göreve teklif verebilir.",
"employer by giving the 
overall quotation. Apply 
for job/ task: in this system,
 the freelancers can apply 
for the job posted by the 
employer by giving the
 overall quotation"=>"Sistemde admin alıcı ve satıcı adına ödeme güvenliğini sağlayacak ve her iki taraftan da komisyonunu alacaktır. Ancak iş  başarılı bir şekilde yapıldıktan sonra admin ",
"In the system, the admin will maintain the payment security on behalf of the buyer and seller and take his commission from both sides. Only after the order is successfully done then the admin will transfer the employers money or payment to the freelancers." => "Sistemde admin alıcı ve satıcı adına ödeme güvenliğini sağlayacak ve her iki taraftan da komisyonunu alacaktır. Ancak iş  başarılı bir şekilde yapıldıktan sonra admin ",
"Freelancers can accept or decline the custom offer from the employer who submitted a custom offer alongside the employer can also accept the bidders and let the bidder start their job/s or tasks" => "Serbest çalışanlar, özel teklif veren işverenin özel teklifini kabul edebilir veya reddedebilir, işverenin yanında teklif verenleri de kabul edebilir ve teklif verenin işe/işlere veya görevlere başlamasına izin verebilir",
"After submitting the task is the employer accepts the order then the order is marked as complete. And give their valuable review to each other Be our returning client" => "Görevi gönderdikten sonra, işveren işi kabul eder, ardından iş tamamlandı olarak işaretlenir. Ve değerli incelemeleri birbirlerinize iletin böylelikle geri dönen müşterileriniz olsun.",
"We are ensuring the best quality freelancer in our platform to enforce our employer came back again and again" => "İşverenimizin tekrar geri gelmesini sağlamak için platformumuzdaki en kaliteli serbest çalışanı sağlıyoruz.",
"You’re safe with us" =>"Bizimle güvendesiniz",
"You get what you pay for. 
And we can prove it.
On hourly contracts,
 we count keystrokes and 
take random screenshots 
of your freelancer’s screen
 so you can see they’re putting
 in the time.
On fixed price contracts,
 you agree on milestones 
and only pay up when those
 milestones are hit." => "Ödediğini alırsın. Ve bunu kanıtlayabiliriz. Saatlik sözleşmelerde, tuş vuruşlarını sayar ve zamanı nasıl harcadıklarını görebilmeniz için serbest çalışanınızın ekranının rastgele ekran görüntülerini alırız. Sabit fiyatlı sözleşmelerde, kilometre taşları üzerinde anlaşmaya varırsınız ve yalnızca bu kilometre taşlarına ulaşıldığında ödeme yaparsınız.",
 "Payment secured by admin"=>"Ödeme yönetici tarafından güvence altına alındı",
 "Just post your job for a team or individual and make your job done fast and easy but very excellent.For big projects freelancers and employers, can both build their own powerful and expert team to complete their tasks." => "Sadece bir ekip veya birey için işinizi gönderin ve işinizi hızlı ve kolay ama çok mükemmel yapın. Büyük projeler için serbest çalışanlar ve işverenler, görevlerini tamamlamak için kendi güçlü ve uzman ekiplerini kurabilirler.",
 "Complete the order" => "İşinizi tamamlayın",
  "You’re safe with us"=>"Bizimle güvendesiniz",
  "Build your team"=>"Takımını kur",
  "employer by giving the overall quotation. Apply for job/ task: in this system, the freelancers can apply for the job posted by the employer by giving the overall quotation"=>"işverene genel fiyat teklifi vererek. İş/Görev Başvurusu: Bu sistemde freelance çalışanlar, işveren tarafından ilan edilen işe genel fiyat teklifi vererek başvuruda bulunabilirler.",



"Let’s get to work"=>"Hadi çalışalım",
"Let’s get to 
work"=>"Hadi çalışalım",
"Build relationships and create your own Virtual Talent Bench™ for quick project turnarounds or big transformations." =>"Hızlı proje geri dönüşleri veya büyük dönüşümler için ilişkiler kurun ve kendi Virtual Talent Bench™'inizi yaratın.",
"Connect with talent that gets you with Talent Marketplace.  Post your job on the world’s work marketplace and wait for the proposals to flood in from talented people around the world. Our advanced algorithms help you shortlist candidates who are the best fit. And you can check profiles, portfolios, and reviews before you give someone the green light." => "Talent Marketplace ile sizi yakalayan yeteneklerle bağlantı kurun. Dünyanın iş piyasasında işinizi yayınlayın ve dünyanın her yerinden yetenekli insanlardan teklif gelmesini bekleyin. Gelişmiş algoritmalarımız, en uygun adayları listeye almanıza yardımcı olur. Birisine yeşil ışık yakmadan önce profilleri, portföyleri ve incelemeleri kontrol edebilirsiniz.",
"Post a job and hire a pro" =>"Bir iş ilanı verin ve bir profesyonel işe alın ",
"All in one place" => "Hepsi bir yerde",
"Once you sign in you’ll get your own online space to manage your project. Use it to securely send and receive files, give real-time feedback and make payments. And if you’re out and about a lot, you’ll want to download  the app too. " => "Oturum açtığınızda, projenizi yönetmek için kendi çevrimiçi alanınıza sahip olacaksınız. Dosyaları güvenli bir şekilde göndermek ve almak, gerçek zamanlı geri bildirim vermek ve ödeme yapmak için bunu kullanın. Dışarıya çok çıkıyorsanız, uygulamamızı da indirebilirsin",
"Find Talent "=> "Yetenek Bul",
"Filter bidding from top 
talents" => "En iyi yeteneklerden gelen teklifleri filtreleyin",
"Bid for task: In this system,
 the freelancers can bid for 
the task posted by the 
employer by giving the 
overall quotation." => "Görev için teklif verme: Bu sistemde freelance çalışanlar, işverenin verdiği göreve teklif verebilir.",
"employer by giving the 
overall quotation. Apply 
for job/ task: in this system,
 the freelancers can apply 
for the job posted by the 
employer by giving the
 overall quotation"=>"İşverene genel fiyat teklifi verilir. İş/Görev Başvurusu: Bu sistemde freelance çalışanlar, işveren tarafından ilan edilen işe genel fiyat teklifi vererek başvuruda bulunabilirler.",
"In the system, the admin will maintain the payment security on behalf of the buyer and seller and take his commission from both sides. Only after the order is successfully done then the admin will transfer the employers money or payment to the freelancers. "=> "Sistemde yönetici, alıcı ve satıcı adına ödeme güvenliğini sağlayacak ve komisyonunu her iki taraftan da alacaktır. Ancak sipariş başarıyla tamamlandıktan sonra yönetici, işverenin parasını veya ödemesini serbest çalışanlara aktaracaktır.",
"Freelancers can accept or decline the custom offer from the employer who submitted a custom offer alongside the employer can also accept the bidders and let the bidder start their job/s or tasks" => "Serbest çalışanlar, işverenin yanında özel bir teklif sunan işverenden gelen özel teklifi kabul edebilir veya reddedebilir, ayrıca teklif verenleri kabul edebilir ve teklif verenin işine/işlerine veya görevlerine başlamasına izin verebilir.",
"After submitting the task is the employer accepts the order then the order is marked as complete. And give their valuable review to each other Be our returning client" => "Görevi gönderdikten sonra, işveren işi kabul eder, ardından iş tamamlandı olarak işaretlenir. Ve değerli incelemeleri birbirlerinize iletin böylelikle geri dönen müşterileriniz olur.",
"We are ensuring the best quality freelancer in our platform to enforce our employer came back again and again" => "İşverenimizin tekrar geri gelmesini sağlamak için platformumuzdaki en kaliteli serbest çalışanı sağlıyoruz.",
"You’re safe with us "=>"Bizimle güvendesiniz",
"You get what you pay for. 
And we can prove it.
On hourly contracts,
 we count keystrokes and 
take random screenshots 
of your freelancer’s screen
 so you can see they’re putting
 in the time.
On fixed price contracts,
 you agree on milestones 
and only pay up when those
 milestones are hit." => "Ödediğini alırsın. Ve bunu kanıtlayabiliriz. Saatlik sözleşmelerde, tuş vuruşlarını sayar ve zamanı nasıl harcadıklarını görebilmeniz için serbest çalışanınızın ekranının rastgele ekran görüntülerini alırız. Sabit fiyatlı sözleşmelerde, kilometre taşları üzerinde anlaşmaya varırsınız ve yalnızca bu kilometre taşlarına ulaşıldığında ödeme yaparsınız.",
 "Payment secured by admin"=>"Ödeme yönetici tarafından güvence altına alındı",
 "Just post your job for a team or individual and make your job done fast and easy but very excellent.For big projects freelancers and employers, can both build their own powerful and expert team to complete their tasks." => "Sadece bir ekip veya birey için işinizi gönderin ve işinizi hızlı ve kolay ama çok mükemmel yapın. Büyük projeler için serbest çalışanlar ve işverenler, görevlerini tamamlamak için kendi güçlü ve uzman ekiplerini kurabilirler.",
 "Complete the order" => "İşinizi tamamlayın",
  "You’re safe with us"=>"Bizimle güvendesiniz",
  "Build your team"=>"Takımını kur",
  "employer by giving the overall quotation. Apply for job/ task: in this system, the freelancers can apply for the job posted by the employer by giving the overall quotation"=>"işverene genel fiyat teklifi vererek. İş/Görev Başvurusu: Bu sistemde freelance çalışanlar, işveren tarafından ilan edilen işe genel fiyat teklifi vererek başvuruda bulunabilirler.",

  "Join the worlds work marketplace"=>"Dünyanın iş piyasasına katılın",
  "Accept your offer"=>"teklifinizi kabul edin",

]; 