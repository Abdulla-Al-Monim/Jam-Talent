<?php
return[
	"In-Demand Talent Categories"=>"Talep Edilen Yetenek Kategorileri",
	"Become an Employer"=>"İşveren Olun",
	"Become a Freelancer"=>"Serbest Çalışan Olun",
	"Privacy Policy"=>"Gizlilik Politikası",
	"Sign Up For a Newsletter"=>"اSign Up For a Newsletter",
	"Weekly breaking news, analysis and cutting edge advices on job searching."=>"اHaftalık son dakika haberleri, analizler ve iş aramayla ilgili en son tavsiyeler.",
	"All Rights Reserved."=>"Her hakkı saklıdır.",
	"Payment secure by stripe"=>"اŞerit ile güvenli ödeme",
	"Helpful Links"=>"Faydalı Bağlantılar",
	"Enter your email address"=>"E-posta adresinizi giriniz",



	"In-Demand Talent Categories"=>"Talep Edilen Yetenek Kategorileri",								
"Become an Employer"=>"İşveren Olun",								
"Become a Freelancer"=>"Serbest Çalışan Olun",								
"Privacy Policy"=>"Gizlilik Politikası",								
"Sign Up For a Newsletter"=>"Bültenimize Kayıt Olun",								
"Weekly breaking news, analysis and cutting edge advices on job searching."=>"Haftalık son dakika haberleri, analizler ve iş aramayla ilgili en son tavsiyeler.",								
"All Rights Reserved."=>"Her hakkı saklıdır.",								
"Payment secure by stripe"=>"Stripe ile güvenli ödeme",								
"Helpful Links"=>"Faydalı Bağlantılar",								
"Enter your email address"=>"E-posta adresinizi giriniz",								

]; 