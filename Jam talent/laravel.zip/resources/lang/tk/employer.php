<?php
return[
	"Home"=>"Ev",
	"Browse Employer"=>"İşverene Gözat",
	"About Employer"=>"İşveren Hakkında",
	"Reviews"=>"incelemeler",
	"Doing things the right way"=>"İşleri doğru şekilde yapmak",
	"Anonymous Employee"=>"Anonim Çalışan",


	"Home"=>"Ana Sayfa",
"Browse Employer"=>"İşverene Gözat",
"About Employer"=>"İşveren Hakkında",
"Reviews"=>"İncelemeler",
"Doing things the right way"=>"İşleri doğru şekilde yap",
"Anonymous Employee"=>"Anonim Çalışan",

	
]; 
