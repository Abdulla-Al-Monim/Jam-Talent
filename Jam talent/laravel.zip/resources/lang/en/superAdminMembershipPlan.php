<?php 
 return[
 	"Description"=>"Description",
 	"Sort description"=>"Sort description",
    "Are you sure you want to delete blog?"=>"Are you sure you want to delete blog?",
    "Membership Plan"=>"Membership Plan",
    "Duration"=>"Duration",
    "Expired Date"=>"Expired Date",
    
"Add Membership Plan"=>"Add Membership Plan",
   "Plan Name" =>"Plan Name",
   "Billed type"  =>"Billed type",
   "Basic"=>"Professional",
   "Standard" =>"Plus Team",
   "Extended" =>"Enterprise",
   "Hourly"=>"Hourly",
   "Monthly"  =>"Monthly",
   "Rate" =>"Rate",
   "All Membership Plans"=>"All Membership Plans",
   "Membership Plans"  =>"Membership Plans",
   "Status"=>"Status",
   "Action"  =>"Action",
   "Delete Membership Plan"  =>"Delete Membership Plan",
   "Are you sure you 
want to delete blog?" =>"Are you sure you 
want to delete blog?",
"Confirm" =>"Confirm",
   "One Mounth"=>"One Month",
   "Get Jobs done cheaper & faster"=>"Get Jobs done cheaper & faster",
   "Create your own online digital agency"=>"Create your own online digital agency",
   "Hire top talents on demand"=>"Hire top talents on demand",

 ];