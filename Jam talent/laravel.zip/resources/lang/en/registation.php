<?php 
 return [
 	"One Account - All of Jam"=> "One Account - All of Jam",
    "Powered by Jam Unity"=>"Powered by Jam Unity",
    "Dont have Account Sign Up!"=>"Don't have Account Sign Up!",
    "Log In"=>"Log In",
    "Forgot Password?"=> "Forgot Password?",
    
    "Freelancer" => "Freelancer",
    "Employer" =>"Employer",
    "Email Address"=> "Email Address",
    
    "Password"=> "Password",
    "Repeat Password"=> "Repeat Password",
    "Already have an account?" => "Already have an account?",
    "REGISTER"=>"REGISTER",
 ];