<?php
return [
	"Let’s get to 
work"=> "Let’s get to 
work",
"Build relationships and create your own Virtual Talent Bench™ for quick project turnarounds or big transformations." => "Build relationships and create your own Virtual Talent Bench™ for quick project turnarounds or big transformations.",
"Connect with talent that gets you with Talent Marketplace
            Post your job on the world’s work marketplace and wait for the proposals to flood in from talented people around the world. Our advanced algorithms help you shortlist candidates who are the best fit. And you can check profiles, portfolios, and reviews before you give someone the green light." => "Connect with talent that gets you with Talent Marketplace
            Post your job on the world’s work marketplace and wait for the proposals to flood in from talented people around the world. Our advanced algorithms help you shortlist candidates who are the best fit. And you can check profiles, portfolios, and reviews before you give someone the green light.",
            "Post a job and hire a pro" => "Post a job and hire a pro",
            "All in one place" => "All in one place",
            "Once you sign in you’ll get 
your own online space to 
manage your project.
Use it to securely send and 
receive files, give real-time 
feedback and make 
payments. And if you’re 
out and about a lot, 
you’ll want to download
 the app too." => "Once you sign in you’ll get 
your own online space to 
manage your project.
Use it to securely send and 
receive files, give real-time 
feedback and make 
payments. And if you’re 
out and about a lot, 
you’ll want to download
 the app too.",
"Find Talent" => "Find Talent",
"Filter bidding from top 
talents" => "Filter bidding from top 
talents",
"Bid for task: In this system,
 the freelancers can bid for 
the task posted by the 
employer by giving the 
overall quotation." => "Bid for task: In this system,
 the freelancers can bid for 
the task posted by the 
employer by giving the 
overall quotation.",
"In the system, the admin will maintain the payment security on behalf of the buyer and seller and take his commission from both sides. Only after the order is successfully done then the admin will transfer the employers money or payment to the freelancers." => "In the system, the admin will maintain the payment security on behalf of the buyer and seller and take his commission from both sides. Only after the order is successfully done then the admin will transfer the employer's money or payment to the freelancers.",
"Freelancers can accept or decline the custom offer from the employer who submitted a custom offer alongside the employer can also accept the bidders and let the bidder start their job/s or tasks" => "Freelancers can accept or decline the custom offer from the employer who submitted a custom offer alongside the employer can also accept the bidders and let the bidder start their job/s or tasks",
"After submitting the task is the employer accepts the order then the order is marked as complete. And give their valuable review to each other Be our returning client" => "After submitting the task is the employer accepts the order then the order is marked as complete. And give their valuable review to each other Be our returning client",
"We are ensuring the best quality freelancer in our platform to enforce our employer came back again and again" => "We are ensuring the best quality freelancer in our platform to enforce our employer came back again and again",
"employer by giving the 
overall quotation. Apply 
for job/ task: in this system,
 the freelancers can apply 
for the job posted by the 
employer by giving the
 overall quotation"=>"In the system, the admin will maintain the payment security on behalf of the buyer and seller and take his commission from both sides. Only after the order is successfully done then the admin will transfer the employer's money or payment to the freelancers.",
 "Accept your offer"=> "Accept your offer",
 "You’re safe with us" =>"You’re safe with us",
 "You get what you pay for. 
And we can prove it.
On hourly contracts,
 we count keystrokes and 
take random screenshots 
of your freelancer’s screen
 so you can see they’re putting
 in the time.
On fixed price contracts,
 you agree on milestones 
and only pay up when those
 milestones are hit." =>  "You get what you pay for. 
And we can prove it.
On hourly contracts,
 we count keystrokes and 
take random screenshots 
of your freelancer’s screen
 so you can see they’re putting
 in the time.
On fixed price contracts,
 you agree on milestones 
and only pay up when those
 milestones are hit.",
 "Payment secured by admin"=>"Payment secured by admin",
 "Just post your job for a team or individual and make your job done fast and easy but very excellent.For big projects freelancers and employers, can both build their own powerful and expert team to complete their tasks." => "Just post your job for a team or individual and make your job done fast and easy but very excellent.For big projects freelancers and employers, can both build their own powerful and expert team to complete their tasks.",
 "Complete the order" => "Complete the order",
 "You’re safe with us"=>"You’re safe with us",
 "Build your team"=>"Build your team",
  "employer by giving the overall quotation. Apply for job/ task: in this system, the freelancers can apply for the job posted by the employer by giving the overall quotation"=>"employer by giving the overall quotation. Apply for job/ task: in this system, the freelancers can apply for the job posted by the employer by giving the overall quotation",
  "Join the worlds work marketplace"=>"Join the world's work marketplace",
]; 