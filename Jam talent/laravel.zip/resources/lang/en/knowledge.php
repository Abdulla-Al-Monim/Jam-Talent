<?php 
return[
	"Home"=>"Home",
	"Knowledge Hub"=>"Knowledge Hub",
	"There is no blog posted in this category"=>"There is no blog posted in this category",
	"Trending Posts"=>"Trending Posts",
	"Social Profiles"=>"Social Profiles",
	"Interesting"=>"Interesting",
	"Share It!"=>"Share It!",
	"Blog Post"=>"Blog Post",
	"Blog Post page"=>"Blog Post page",
	"Blog"=>"Blog",
	"Recent Posts"=>"Recent Posts",
	"Featured Posts"=>"Featured Posts",
	"Tags"=>"Tags",
	"Showcase your knowledge & skills to get hired faster"=>"Showcase your knowledge & skills to get hired faster",
];