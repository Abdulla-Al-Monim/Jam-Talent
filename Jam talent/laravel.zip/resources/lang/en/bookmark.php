<?php 
	return[
		"Bookmarks"=>"Bookmarks",
		"Bookmarked Freelancers"=>"Bookmarked Freelancers",
		"Unknown"=>"Unknown",
		"Home"=>"Home",
		"Dashboard"=>"Dashboard",
		"Bookmarked Jobs"=>"Bookmarked Jobs",
		"Bookmarked Task"=>"Bookmarked Task",
	];