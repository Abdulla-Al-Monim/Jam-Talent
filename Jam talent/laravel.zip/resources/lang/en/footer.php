<?php
return[
	"In-Demand Talent Categories"=>"In-Demand Talent Categories",
	"Become an Employer"=>"Become an Employer",
	"Become a Freelancer"=>"Become a Freelancer",
	"Privacy Policy"=>"Privacy Policy",
	"Sign Up For a Newsletter"=>"Sign Up For a Newsletter",
	"Weekly breaking news, analysis and cutting edge advices on job searching."=>"Weekly breaking news, analysis and cutting edge advices on job searching.",
	"All Rights Reserved."=>"All Rights Reserved.",
	"Payment secure by stripe"=>"Payment secure by stripe",
	"Helpful Links"=>"Helpful Links",
	"Enter your email address"=>"Enter your email address",
]; 