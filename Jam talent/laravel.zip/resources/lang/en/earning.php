<?php 
return [
	"Order Id"=>"Order Id",
	"Employer name"=>"Employer name",
	"Earning balance"=>"Earning balance",
	"Order type"=>"Order type",
	"Completed date"=>"Completed date",
	"Status"=>"Status",
	"Custom Offer"=>"Custom Offer",
	"Bid Order"=>"Bid Order",
	"Payment within 14 days"=>"Payment within 14 days",
	"Complete"=>"Complete",
	"Total Earn"=>"Total Earn",
	"Earning"=>"Earning",
	
];