<?php 
return[
	"Messages"=>"Messages",
	"Home"=>"Home",
	"Dashboard"=>"Dashboard",
	"First you send message anyone"=>"First you send message anyone",
	"Send"=>"Send",
	"Your Message"=>"Your Message",
];