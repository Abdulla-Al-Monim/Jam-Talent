<?php
return[
	"Home"=>"Home",
	"Browse Employer"=>"Browse Employer",
	"Browse Employer"=>"Browse Employer",
	"Reviews"=>"Reviews",
	"Doing things the right way"=>"Doing things the right way",
	"Anonymous Employee"=>"Anonymous Employee",
	"About Employer"=>"About Employer",
	
];