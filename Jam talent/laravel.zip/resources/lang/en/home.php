<?php 
return [
	"Hire the top and verified
Freelancer Talents to turn your ideas into reality"=> "Hire the top and verified
Freelancer Talents to turn your ideas into reality",
"The largest network of 
top extraordinary 
freelancers for short term and long-term tasks/jobs marketplace solutions. JamTalent is a perfect solution for individuals or any agency’s to filter out their perfect candidates." => "The largest network of 
top extraordinary 
freelancers for short term and long-term tasks/jobs marketplace solutions. JamTalent is a perfect solution for individuals or any agency’s to filter out their perfect candidates.",
"Where" => "Where",
"Location" => "Location",
"What job you want" => "What job you want",
"Job Title"=> "Job Title",
"Search" => "Search",
"Get in-demand talent
on demand." => "Get in-demand Talent
on demand.",
"You’re on your way to 
connecting with great!
 talent"=> "You’re on your way to 
connecting with great!
 Talent",
 "Jobs Posted" => "Jobs Posted",
 "Tasks Posted"=> "Tasks Posted",
 "Freelancers" => "Freelancers",
 "Build Amazing Teams, 
On Demand"=> "Build Amazing Teams, 
On Demand",
"Hire Quickly" => "Hire Quickly",
"Immediately, we will 
introduce you to the 
perfect talent for 
your project. Average 
time to match is less 
than 24 hours." => "Immediately, we will 
introduce you to the 
perfect talent for 
your project. Average 
time to match is less 
than 24 hours.",
"Prebuilt our expert 
team"=> "Prebuilt our expert 
team",
"A professional expert 
on our team will work 
with you to understand 
your goals, technical 
needs, and team 
dynamics." =>"A professional expert 
on our team will work 
with you to understand 
your goals, technical 
needs, and team 
dynamics.",
"Short/long term 
projects" =>
"Short/long term 
projects",
"Work with diverse new 
team member in a 
short and long term 
projects, and hire 
qualified freelancers to ensure you hire the right people for the job."=> "Work with diverse new 
team member in a 
short and long term 
projects, and hire 
qualified freelancers to ensure you hire the right people for the job.",
"Build or hire expert 
team" => "Build or hire expert 
team",
"Just post your job 
for a team or 
individual and make 
you job done fast and 
easy but very excellent." => "Just post your job 
for a team or 
individual and make 
you job done fast and 
easy but very excellent." ,
"For talent" => "For Talent", 
"Find great" => "Find great",
"Meet clients youre 
excited to work with 
and take" => "Meet clients you're 
excited to work with 
and take",
"your career or business
to new heights." => 
"your career or business
to new heights.",
"Find opportunities for
every stage of your 
freelance career" => "Find opportunities for
every stage of your 
freelance career",
"Find opportunities for 
every stage of your 
freelance career"=> "Find opportunities for 
every stage of your 
freelance career",
"Choose Perfect Bidders" => "Choose Perfect Bidders",
"You can simply browse from among 
the top skilled freelancers or choose
 you candidates from the bidders 
from your job posting." => "You can simply browse from among 
the top skilled freelancers or choose
 you candidates from the bidders 
from your job posting.",
"Secured Payment System" => "Secured Payment System",
"We offer both employer 
and freelancer have 
security of their 
payment and the 
payment will be done 
only after the work 
is successfully done." => "We offer both employer 
and freelancer have 
security of their 
payment and the 
payment will be done 
only after the work 
is successfully done.",
"Browse All Jobs" => "Browse All Jobs",
"Featured Task" => "Featured Tasks",
"Browse All Task" => "Browse All Task",
"Browse All Task" => "Browse All Task",
"Dubai"=> "Dubai",
"Istanbul" => "Istanbul",
"Cairo" => "Cairo",
"Riyadh" => "Riyadh",
"Highest Rated 
Freelancers"=> "Highest Rated 
Freelancers",
"Browse All Freelancers" => "Browse All Freelancers",
"Membership Plans" => "Membership Plans",
"What they're saying"=>"What they're saying",
"The freelance talent 
we work with are more 
productive than we 
ever thought possible." => "The freelance talent 
we work with are more 
productive than we 
ever thought possible.",
"Care Bedford" => "Care Bedford",
"Director of strategic 
Marketing,CompuVision" => "Director of strategic 
Marketing,CompuVision",
"The freelance talent we work with are
 more productive than we ever thought
 possible." => "The freelance talent we work with are
 more productive than we ever thought
 possible.",
 "Director of strategic Marketing,Compu
Vision" => "Director of strategic Marketing,Compu
Vision",
"In-Demand Talent Categories" => "In-Demand Talent Categories",
"About Us" =>"About Us",
"How" => "How",
"Become a Employer" =>"Become a Employer",
"Become a Freelancer" =>"Become a Freelancer",
"Find top talents"=> "Find top talents",
"Join the world"=>"Join the world's",
"work marketplace"=>"work marketplace",
"Find great talent. Build your business."=>"Find great Talent. Build your business.",
"Take your career to the next level."=>"Take your career to the next level.",
"Find Talent"=>"Find Talent",
"Find Work"=>"Find Work",
"Quickly assemble the teams you need, exactly when you need them."=>"Quickly assemble the teams you need, exactly when you need them.",
"Easy Hiring"=>"Easy Hiring",
"Post Jobs"=>"Post Jobs",
"Or"=>"Or",
"Tasks"=>"Tasks",
"Featured Jobs"=>"Featured Jobs",
"Our Franchise Cities"=>"Our Franchise Cities",
"View Profile"=>"View Profile",
"Billed Monthly"=>"Billed Monthly",
"First Month Free Trial"=>"First Month Free Trial",
"work"=>"work",
"Find Opportunities"=>"Find Opportunities",
"Apply Now"=>"Apply Now",
"Free Trial"=>"Free Trial",
"What theyre saying"=>"What they are saying",

"It is a simple process of posting jobs/tasks and gets rapid job application for your jobs"=>"It is a simple process of posting jobs/tasks and gets rapid job application for your jobs",
"Our Clients
Jam Talent connects elite talent with the most exciting companies in the world, including leading Fortune 500 brands and innovative Silicon Valley startups. Our focus on challenging, tier-one projects powers the world’s largest high-skilled workforce."=>"Our Clients
Jam Talent connects elite talent with the most exciting companies in the world, including leading Fortune 500 brands and innovative Silicon Valley startups. Our focus on challenging, tier-one projects powers the world’s largest high-skilled workforce.",
"Hire the Top 3% of Freelancers and Talents. 
Jam Talent is an exclusive platform for the top freelance software developers, designers, finance experts, product managers, and project managers in the world. Top companies hire Jam Talent freelancers for their most important projects."=>"Hire the Top 3% of Freelancers and Talents. 
Jam Talent is an exclusive platform for the top freelance software developers, designers, finance experts, product managers, and project managers in the world. Top companies hire Jam Talent freelancers for their most important projects.",
"For HR Developments"=>"For HR Developments",
"For Employers"=>"For Employers",
"Find flexible work"=>"Find flexible work",
"Control when , where and how you work"=>"Control when , where and how you work",
"Explore different ways to earn"=>"Explore different ways to earn",
"Find Talent on-demand"=>"Find Talent on-demand",
"Work with the largest network of independent professionals and get things done—from quick turnarounds to big transformations."=>"Work with the largest network of independent professionals and get things done—from quick turnarounds to big transformations.",
"Complete projects before the deadlines"=>"Complete projects before the deadlines",
"Discover Top 3% of Talents"=>"Discover Top 3% of Talents",
"& Freelancers"=>"& Freelancers",
"Hire Professionals"=>"Hire Professionals",
"Hire a pro
for any skill"=>"Hire a pro
for any skill",
    "Order Complete"=>"Order Complete",
"Create your own online digital agency"=>"Create your own online digital agency",
"Hire top talents on demand"=>"Hire top talents on demand",

"Get Jobs done cheaper & faster"=>"Get Jobs done cheaper & faster",
"For Agencies"=>"For Agencies",
"For HR Departments"=>"For HR Departments",
"From Job Search"=>"From Job Search",
"To Job Success..."=>"To Job Success...",
"Free training and resources to help you learn new skills, find job opportunities, and grow your career." => "Free training and resources to help you learn new skills, find job opportunities, and grow your career.",
"SUCCEED TODAY" => "SUCCEED TODAY",
"Skills Based Jobs" => "Skilled Based Jobs",
"Skills Based Courses" => "Skills Based Courses",
"Skills Based Instructors" => "Skills Based Instructors",
"Partner Employers" => "Partner Employers",
"We are powered by industry…" => "We are powered by industry…",
"Build Your Career" => "Build Your Career",
"Build Your Workforce"=> "Build Your Workforce",
"Our Internship, Apprenticeship, And Scholarship programs are built in partnership with the world’s most innovative tech companies and sponsored by industry leaders.
 Whether you’re just starting out, upskilling, or looking for a career change – there’s an career development program for everyone."=> "Our Internship, Apprenticeship, And Scholarship programs are built in partnership with the world’s most innovative tech companies and sponsored by industry leaders.
 Whether you’re just starting out, upskilling, or looking for a career change – there’s an career development program for everyone.",
  "Jobs for All of Our Talents." => "Jobs for All of Our Talents.",
  "Talents for All of Employers" => "Talents for All of Employers",
  "Projects for Education Institutions" => "Projects for Education Institutions",
"Skills for national workforce" => "Skills for national workforce",
"Contact Reason" => "Contact Reason",
"Interest Type of" => "Interest Type of",
"Name" => "Name",
"Last" => "Last",
"First" => "First",
"Position" => "Position",
"Job Title"=> "Job Title",
"Organization Name" => "Organization Name",
"Company Name" => "Company Name",
"Office Address" => "Office Address",
"Email" => "Email",
"Contact Telephone Number"=> "Contact Telephone Number",
"Website URL Address" => "Website URL Address",
"Whatsapp Messaging Number"=> "Whatsapp Messaging Number",
"Cover Letter"=> "Cover Letter",
"Help us decide the fastest way to process your application" => "Help us decide the fastest way to process your application",
"Upload Attachment" => "Upload Attachment",
"CV, Job Requirements, and or Company Profile"=> "CV, Job Requirements, and or Company Profile",
 "SUBMIT" => "SUBMIT",
 "Internship"  => "Internship",
 "Apprentership"=> "Apprentership",
 "Scholarship" => "Scholarship",
 "Sponsorship"=> "Sponsorship",
  "Employer (Business)"=> "Employer (Business)",
  "I am a Job Seeker (Talent )"  => "I am a Job Seeker (Talent )",
  "Educational Institute"=> "Educational Institute",
  "Educational Institute" => "Educational Institute",
  "Rate"=>"Rate",
];