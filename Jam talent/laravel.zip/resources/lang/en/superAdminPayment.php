<?php 
return[
	"Task Title"=>"Task Title",
	"Custom Offer Payment"=>"Custom Offer Payment",
 	"Employer Name"=>"Employer Name",
 	"Freelancer Name" =>"Freelancer Name",
 	"Transaction id"  =>"Transaction id",
 	"Post date"=>"Post date",
 	"Custom Offer"  =>"Custom Offer",
 	"Job Payment"=>"Job Payment",
 	"Employer Name" =>"Employer Name",
 	"Freelancer Name"=>"Freelancer Name",
 	"Budget"=>"Budget",
 	"Task Payment"=>"Task Payment",
 	"Job Title"=>"Job Title",
];