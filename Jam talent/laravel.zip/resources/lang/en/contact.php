<?php 
return[
	"get in touch"=>"get in touch",
	"Full Name"=>"Full Name",
	"Email"=>"Email",
	"Phone Number"=>"Phone Number",
	"Messages"=>"Messages",
	"SEND"=>"SEND",
	"Contact Information"=>"Contact Information",
	
];