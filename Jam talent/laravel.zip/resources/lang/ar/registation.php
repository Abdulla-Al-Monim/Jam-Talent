<?php 
 return [
 	"One Account - All of Jam"=> "حساب واحد - لكل  Jam ",
 	"Powered by Jam Unity"=>"بدعم من Jam Unity",
 	"Dont have Account Sign Up!"=>"ليس لديك تسجيل حساب!",
 	"Log In"=>"تسجيل دخول",
 	"Forgot Password?"=> "هل نسيت كلمة السر؟",
 	
 	"Freelancer" => "مستقل",
 	"Employer" => "صاحب العمل",
 	"Email Address"=> "عنوان البريد الإلكتروني",
 	
 	"Password"=> "كلمه المرور",
 	"Repeat Password"=> "اعادة كلمة المرور",
 	"Already have an account?" => "هل لديك حساب؟",
    "REGISTER"=>"تسجيل",



      "One Account - All of Jam"=> "حساب واحد - لكل مجتمع  Jam ",
   "Powered by Jam Unity"=>"بدعم من Jam Unity",
   "Dont have Account Sign Up!"=>"ليس لديك تسجيل حساب!",
   "Log In"=>"تسجيل دخول",
   "Forgot Password?"=> "هل نسيت كلمة السر؟",
   
   "Freelancer" => "مستقل",
   "Employer" => "صاحب العمل",
   "Email Address"=> "عنوان البريد الإلكتروني",
   
   "Password"=> "كلمه المرور",
   "Repeat Password"=> "اعادة كلمة المرور",
   "Already have an account?" => "هل لديك حساب؟",
    "REGISTER"=>"تسجيل",   

 ];

