<?php
return[
	"In-Demand Talent Categories"=>"فئات المواهب عند الطلب",
	"Become an Employer"=>"كن صاحب عمل",
	"Become a Freelancer"=>"كن فريلانسر",
	"Privacy Policy"=>"سياسة خاصة",
	"Sign Up For a Newsletter"=>"اشترك في النشرة الإخبارية",
	"Weekly breaking news, analysis and cutting edge advices on job searching."=>"الأخبار العاجلة الأسبوعية والتحليلات وأحدث النصائح حول البحث عن وظيفة.",
	"All Rights Reserved."=>"كل الحقوق محفوظة.",
	"Payment secure by stripe"=>"الدفع آمن عن طريق الشريط",
	"Helpful Links"=>"روابط مفيدة",
	"Enter your email address"=>"أدخل عنوان بريدك الالكتروني",

	"In-Demand Talent Categories"=>"فئات المواهب عند الطلب",	
	"Become an Employer"=>"كن صاحب عمل",
	"Become a Freelancer"=>"كن فريلانسر",
	"Privacy Policy"=>"سياسة خاصة",
	"Sign Up For a Newsletter"=>"اشترك في النشرة الإخبارية",
	"Weekly breaking news, analysis and cutting edge advices on job searching."=>"الأخبار العاجلة الأسبوعية والتحليلات وأحدث النصائح حول البحث عن وظيفة.",
	"All Rights Reserved."=>"كل الحقوق محفوظة.",
	"Payment secure by stripe"=>"الدفع آمن عن طريق stripe",
	"Helpful Links"=>"روابط مفيدة",
	"Enter your email address"=>"أدخل عنوان بريدك الالكتروني",

]; 