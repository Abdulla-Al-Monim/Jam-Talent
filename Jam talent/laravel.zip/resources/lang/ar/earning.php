<?php 
return [
	
	"Earning"=>"كسب",
	"Order Id"=>"رقم التعريف الخاص بالطلب",
	"Employer name"=>"اسم الموظف",
	"Earning balance"=>"كسب الرصيد",
	"Order type"=>"نوع الطلب",
	"Completed date"=>"تاريخ الانتهاء",
	"Status"=>"حالة",
	"Custom Offer"=>"عرض مخصص",
	"Bid Order"=>"ترتيب العطاء",
	"Payment within 14 days"=>"الدفع خلال 14 يوم",
	"Complete"=>"مكتمل",
	"Total Earn"=>"إجمالي الكسب",


	"Earning"=>"كسب",	
	"Order Id"=>"رقم   بالطلب",
	"Employer name"=>"اسم صاحب العمل",
	"Earning balance"=>"كسب الرصيد",
	"Order type"=>"نوع الطلب",
	"Completed date"=>"تاريخ الانتهاء",
	"Status"=>"الحالة",
	"Custom Offer"=>"عرض مخصص",
	"Bid Order"=>"ترتيب العروض",
	"Payment within 14 days"=>"الدفع خلال 14 يوم",
	"Complete"=>"مكتمل",
	"Total Earn"=>"إجمالي الكسب",

	
];