<?php 
return[
	"Task Title"=>"عنوان المهمة",
	"Custom Offer Payment"=>"دفع العرض المخصص",
 	"Employer Name"=>"اسم الموظف",
 	"Freelancer Name" =>"اسم المستقل",
 	"Transaction id"  =>"رقم المعاملة",
 	"Post date"=>"تاريخ آخر",
 	"Custom Offer"  =>"عرض مخصص",
 	"Job Payment"=>"دفع الوظيفة",
 	"Employer Name" =>"اسم الموظف",
 	"Freelancer Name"=>"اسم المستقل",
 	"Budget"=>"الدخل",
 	"Task Payment"=>"دفع المهمة",
 	"Job Title"=>"عنوان وظيفي",


	"Task Title"=>"عنوان المهمة",
	"Custom Offer Payment"=>"دفع العرض المخصص",
	"Employer Name"=>"اسم الموظف",
	"Freelancer Name" =>"اسم المستقل",
	"Transaction id " =>"رقم المعاملة",
	"Post date"=>"تاريخ النشر",
	"Custom Offer  "=>"عرض مخصص",
	"Job Payment"=>"دفع الوظيفة",
	"Employer Name" =>"اسم الموظف",
	"Freelancer Name"=>"اسم المستقل",
	"Budget"=>"الميزانية",
	"Task Payment"=>"دفع المهمة",
	"Job Title"=>"عنوان وظيفي",
	

];