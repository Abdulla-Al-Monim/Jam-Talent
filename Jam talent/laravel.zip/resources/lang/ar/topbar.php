<?php
	 return[
	 	'AboutUs' => 'علومات عنا,',
	 	'ContactUs' => "اتصل بنا",
	 	"Language" => "اللغة",
	 	"Knowledge Hub" => "مركز المعرفة",
	 	"Login"  => "تسجيل الدخول",
	 	"how" => "كيف",
	 	"Find Talent" => "البحث عن المواهب",
	 	"Happilancing"=>"السعادة",
	 	"language"=>"لغة",
	 	"Freelancer"=>"مستقل",
		"Admin"=>"مشرف",
		"Employer"=>"صاحب العمل",
		"Super Admin"=>"مشرف فائق",
		"Log out"=>"تسجيل خروج",
		"Dashboard"=>"لوحة القيادة",



	"AboutUs" => 'علومات عنا,',
"ContactUs" => "اتصل بنا",
"Language" => "اللغة",
"Knowledge Hub"=> "مركز المعرفة",
"Login"  => "تسجيل الدخول",
"how" => "كيف",
"Find Talent" => "البحث عن المواهب",
"Happilancing"=>"Happilancing",
"language"=>"لغة",
"Freelancer"=>"مستقل",
"Admin"=>"المشرف",
"Employer"=>"صاحب العمل",
"Super Admin"=>"المشرف العام",
"Log out"=>"تسجيل خروج",
"Dashboard"=>"لوحة التحكم",



	 ];
	 
