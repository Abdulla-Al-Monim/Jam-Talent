<?php
return[
	"Description"=>"وصف",
	"Sort description"=>"وصف الفرز",
	"Are you sure you want to delete blog?"=>"هل أنت متأكد أنك تريد حذف المدونة؟",
	"Membership Plan"=>"خطة العضوية",
	"Duration"=>"مدة",
	"Expired Date"=>"منتهي الصلاحية",
	"Add Membership Plan"=>"إضافة خطة عضوية",
   "Plan Name" =>"اسم الخطة",
   "Billed type"  =>"نوع الفاتورة",
   "Basic"=>"احترافي",
   "Standard" =>"فريق بلس",
   "Extended" =>"المؤسسة",
   "Hourly"=>"ساعيا",
   "Monthly"  =>"شهريا",
   "Rate" =>"معدل",
   "All Membership Plans"=>"جميع خطط العضوية",
   "Membership Plans"  =>"خطط العضوية",
   "Status"=>"حالة",
   "Action"  =>"عمل",
   "Delete Membership Plan"  =>"حذف خطة العضوية",
   "Are you sure you 
want to delete blog?" =>"هل انت متأكد انك
تريد حذف المدونة؟",
"Confirm" =>"يتأكد",


"Description"=>"وصف",
"Sort description"=>"وصف بسيط",
"Are you sure you want to delete blog?"=>"هل أنت متأكد أنك تريد حذف المدونة؟",
"Membership Plan"=>"خطة العضوية",
"Duration"=>"المدة",
"Expired Date"=>"منتهي الصلاحية",
"Add Membership Plan"=>"إضافة خطة عضوية",
"Plan Name" =>"اسم الخطة",	
"Billed type"  =>"نوع الفاتورة",	

"Hourly"=>"ساعيا",	
"Monthly"  =>"شهريا",	
"Rate" =>"معدل",	
"All Membership Plans"=>"جميع خطط العضوية",	
"Membership Plans"  =>"خطط العضوية",	
"Status"=>"الحالة",	
"Action"  =>"نشط",	
"Delete Membership Plan"  =>"حذف خطة العضوية",	
"Are you sure you want to delete blog?" =>"هل انت متأكد انك	
تريد حذف المدونة؟",	
"Confirm" =>"تأكيد",	
"One Mounth"=>"شهر واحد",
   "Get Jobs done cheaper & faster"=>"احصل على المهام بشكل أرخص وأسرع",
   "Create your own online digital agency"=>"قم بإنشاء وكالتك الرقمية الخاصة على الإنترنت",
   "Hire top talents on demand"=>"توظيف أفضل المواهب عند الطلب",


];
