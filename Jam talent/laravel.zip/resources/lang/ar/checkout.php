<?php 
 return[
 	"All Membership Payments"=>"جميع مدفوعات العضوية",
 	"Employer Name"=>"اسم الموظف",
 	"Plan name"=>"اسم الخطة",
 	"Transcection id"=>"رقم المعاملة",
 	"Expired date"=>"منتهي الصلاحية",


	"All Membership Payments"=>"جميع مدفوعات العضوية",	
	"Employer Name"=>"اسم صاحب العمل ",
	"Plan name"=>"اسم الخطة",
	"Transcection id"=>"رقم المعاملة",
	"Expired date"=>"منتهي الصلاحية",

];