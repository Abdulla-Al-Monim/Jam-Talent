<?php 
	return[
		"Bookmarks"=>"إشارات مرجعية",
		"Bookmarked Freelancers"=>"المستقلين ذات إشارة مرجعية",
		"Unknown"=>"المرجعية لحسابهم الخاص",
		"Home"=>"الصفحة الرئيسية",
		"Dashboard"=>"لوحة القيادة",
		"Bookmarked Jobs"=>"وظائف مرجعية",
		"Bookmarked Task"=>"مهام مرجعية",


		"Bookmarks"=>"إشارات مرجعية",		
		"Bookmarked Freelancers"=>"المستقلين ذات إشارة مرجعية",
		"Unknown"=>"  غير معروف",
		"Home"=>"الصفحة الرئيسية",
		"Dashboard"=>"لوحة التحكم",
		"Bookmarked Jobs"=>"وظائف مرجعية",
		"Bookmarked Task"=>"مهام مرجعية",

	];