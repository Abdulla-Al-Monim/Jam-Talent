<?php 
return[
	"Home"=>"الصفحة الرئيسية",
	"Knowledge Hub"=>"مركز المعرفة",
	"There is no blog posted in this category"=>"لا توجد مدونة نشرت في هذه الفئة",
	"Trending Posts"=>"المشاركات الشائعة",
	"Social Profiles"=>"لمحات اجتماعية",
	"Interesting"=>"مثير للإعجاب",
	"Share It!"=>"أنشرها!",
	"Blog Post"=>"مشاركة مدونة",
	"Blog Post page"=>"صفحة نشر المدونة",
	"Blog"=>"مدونة او مذكرة",
	"Recent Posts"=>"المشاركات الاخيرة",
	"Featured Posts"=>"المشاركات مميزة",
	"Tags"=>"العلامات",




	"Home"=>"الصفحة الرئيسية",
"Knowledge Hub"=>"مركز المعرفة",
"There is no blog posted in this category"=>"لا توجد مدونة نشرت في هذه الفئة",
"Trending Posts"=>"المشاركات الشائعة",
"Social Profiles"=>"لمحات اجتماعية",
"Interesting"=>"مثير للإعجاب",
"Share It!"=>"أنشرها!",
"Blog Post"=>"مشاركة مدونة",
"Blog Post page"=>"صفحة نشر المدونة",
"Blog"=>"مدونة او مذكرة",
"Recent Posts"=>"المشاركات الاخيرة",
"Featured Posts"=>"المشاركات مميزة",
"Tags"=>"العلامات",
"Showcase your knowledge & skills to get hired faster"=> "  اعرض معرفتك و مهارتك لتوظيفك بشكل اسرع ",

];