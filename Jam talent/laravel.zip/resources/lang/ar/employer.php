<?php
return[
	"Home"=>"الصفحة الرئيسية",
	"Browse Employer"=>"تصفح صاحب العمل",
	"About Employer"=>"عن صاحب العمل",
	"Reviews"=>"المراجعات",
	"Doing things the right way"=>"فعل الأشياء بالطريقة الصحيحة",
	"Anonymous Employee"=>"موظف مجهول",
	

	"Home"=>"الصفحة الرئيسية",	
	"Browse Employer"=>"تصفح صاحب العمل",
	"About Employer"=>"عن صاحب العمل",
	"Reviews"=>"التقيمات",
	"Doing things the right way"=>"فعل الأشياء بالطريقة الصحيحة",
	"Anonymous Employee"=>"موظف مجهول",

];