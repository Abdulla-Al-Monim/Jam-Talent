<?php 
return[
	"Messages"=>"رسائل",
	"Home"=>"الصفحة الرئيسية",
	"Dashboard"=>"لوحة القيادة",
	"First you send message anyone"=>"أولا ترسل رسالة إلى أي شخص",
	"Send"=>"يرسل",



	"Messages"=>"الرسائل",
	"Home"=>"الصفحة الرئيسية",
	"Dashboard"=>"لوحة التحكم",
	"First you send message anyone"=>"أولا أرسل رسالة إلى أي شخص",
	"Send"=>"إرسال",
	"Your Message"=>"رسالتك",

];