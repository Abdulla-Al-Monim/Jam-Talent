<?php 
return[
	"get in touch"=>"ابقى على تواصل",
	"Full Name"=>"الاسم بالكامل",
	"Email"=>"بريد الالكتروني",
	"Phone Number"=>"رقم الهاتف",
	"Messages"=>"رسائل",
	"SEND"=>"يرسل",
	"Contact Information"=>"معلومات للتواصل	",


	"get in touch"=>"ابقى على تواصل",	
	"Full Name"=>"الاسم بالكامل",
	"Email"=>"بريد الالكتروني",
	"Phone Number"=>"رقم الهاتف",
	"Messages"=>"رسائل",
	"SEND"=>"أرسل",
	"Contact Information"=>"معلومات للتواصل	",

	
];