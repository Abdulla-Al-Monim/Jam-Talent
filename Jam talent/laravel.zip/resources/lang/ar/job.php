<?php
return[
	"Project Budget"=>"ميزانية المشروع",
	 "Job Description"=>"المسمى الوظيفي",
	"Similar Jobs"=>"وظائف مماثلة",
	"Apply Now"=>"قدم الآن",
	"Job Summary"=>"ملخص العمل",
	"Location"=>"موقع",
	"Job Type"=>"نوع الوظيفة",
	"Project Budget"=>"ميزانية المشروع",
	"Date Posted"=>"تاريخ الإعلان",
	"Attach File With CV"=>"إرفاق ملف مع السيرة الذاتية",
	"Salary"=>"مرتب",
	"Budget"=>"الدخل",
	"Add Attachments"=>"أضف ملحقات",
	"Upload your CV/resume relevant file."=>"قم بتحميل سيرتك الذاتية / ملف السيرة الذاتية ذات الصلة.",
	"Max. files size"=>"الأعلى. حجم الملفات",
	"About the Employer"=>"عن صاحب العمل",
	"No Job Found"=>"لم يتم العثور على وظيفة",
	"You are Already Apply this job!"=>"أنت بالفعل تقدم لهذه الوظيفة!",




	"Similar Jobs"=>"وظائف مماثلة",
	"Apply Now"=>"قدم الآن",
	"Job Summary"=>"ملخص العمل",
	"Location"=>"موقع",
	"Job Type"=>"نوع الوظيفة",
	"Project Budget"=>"ميزانية المشروع",
	"Date Posted"=>"تاريخ الإعلان",
	"Attach File With CV"=>"إرفاق ملف مع السيرة الذاتية",
	"Salary"=>"المرتب",
	"Budget"=>"الميزانية",
	"Add Attachments"=>"أضف ملحقات",
	"Upload your CV/resume relevant file."=>"قم بتحميل سيرتك الذاتية / ملف السيرة الذاتية ذات الصلة.",
	"Max. files size"=>"الأعلى. حجم الملفات",
	"About the Employer"=>"عن صاحب العمل",
	"No Job Found"=>"لم يتم العثور على وظيفة",
	"You are Already Apply this job!"=>"أنت بالفعل تقدم لهذه الوظيفة!",

]; 