<?php return array (
  'dashbor.dashbord-component' => 'App\\Http\\Livewire\\Dashbor\\DashbordComponent',
);